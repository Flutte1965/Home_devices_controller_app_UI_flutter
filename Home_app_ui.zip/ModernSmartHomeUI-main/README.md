# MODERN SMART HOME UI x FLUTTER

Watch tutorial here: https://youtu.be/FMV8pbz0sN8

![C6A307C4-3A35-4CD6-BFB1-63B370A1B07F](https://user-images.githubusercontent.com/29016489/200977277-210b239c-fd92-435e-ad99-0cccd6035afd.JPG)
